import{S as ae,i as te,s as oe,k as m,e as n,t as b,T as ne,d as t,m as h,c as s,a as l,h as v,b as r,U as se,g as Z,G as e,R as ee,H as $,V as le}from"../chunks/vendor-1b6b5f47.js";function re(M){let p,a,_,T,x,y,L,A,o,k,H,V,I,C,R,E,S,q,g,P,U,i,w,B,D,f,G,N,z;return{c(){p=m(),a=n("div"),_=n("h1"),T=b("About"),x=m(),y=n("img"),A=m(),o=n("article"),k=n("p"),H=b(`Hello again, as you probably already found out from my home page, my name
      is Mac and I am a frontend developer. I specialise in building sleek, fast
      and easy to maintain websites these sites can hook up to a CMS if you need
      to be able to control your data, I can even add more app like
      functionality such as user sign up and much more.`),V=m(),I=n("p"),C=b(`In my free time, I enjoy writing music in various genres, though I mostly
      specialise in pop punk. I also play a few video games now and then and
      would love to make my own one day.`),R=m(),E=n("p"),S=b(`Anyway enough about me, you are probably more interested in the work I am
      capable of. To have a look through my projects you can click the button
      below. Make sure you click on each project to see the tools I used and
      other interesting information.`),q=m(),g=n("h2"),P=b("Mac"),U=m(),i=n("div"),w=n("button"),B=b("Read my blog"),D=m(),f=n("button"),G=b("View my work"),this.h()},l(c){ne('[data-svelte="svelte-f12wyb"]',document.head).forEach(t),p=h(c),a=s(c,"DIV",{class:!0});var u=l(a);_=s(u,"H1",{class:!0});var F=l(_);T=v(F,"About"),F.forEach(t),x=h(u),y=s(u,"IMG",{src:!0,alt:!0,class:!0}),A=h(u),o=s(u,"ARTICLE",{class:!0});var d=l(o);k=s(d,"P",{});var J=l(k);H=v(J,`Hello again, as you probably already found out from my home page, my name
      is Mac and I am a frontend developer. I specialise in building sleek, fast
      and easy to maintain websites these sites can hook up to a CMS if you need
      to be able to control your data, I can even add more app like
      functionality such as user sign up and much more.`),J.forEach(t),V=h(d),I=s(d,"P",{});var K=l(I);C=v(K,`In my free time, I enjoy writing music in various genres, though I mostly
      specialise in pop punk. I also play a few video games now and then and
      would love to make my own one day.`),K.forEach(t),R=h(d),E=s(d,"P",{});var Q=l(E);S=v(Q,`Anyway enough about me, you are probably more interested in the work I am
      capable of. To have a look through my projects you can click the button
      below. Make sure you click on each project to see the tools I used and
      other interesting information.`),Q.forEach(t),q=h(d),g=s(d,"H2",{class:!0});var W=l(g);P=v(W,"Mac"),W.forEach(t),d.forEach(t),U=h(u),i=s(u,"DIV",{class:!0});var j=l(i);w=s(j,"BUTTON",{});var X=l(w);B=v(X,"Read my blog"),X.forEach(t),D=h(j),f=s(j,"BUTTON",{class:!0});var Y=l(f);G=v(Y,"View my work"),Y.forEach(t),j.forEach(t),u.forEach(t),this.h()},h(){document.title="About | Mac",r(_,"class","title"),se(y.src,L="avatar.jpeg")||r(y,"src",L),r(y,"alt","avatar"),r(y,"class","w-32 h-32 my-4 rounded-full"),r(g,"class","-mt-1"),r(o,"class","w-5/6 max-w-lg mb-8 prose lg:mb-6"),r(f,"class","primary"),r(i,"class","flex items-center space-x-2"),r(a,"class","container flex-col py-6")},m(c,O){Z(c,p,O),Z(c,a,O),e(a,_),e(_,T),e(a,x),e(a,y),e(a,A),e(a,o),e(o,k),e(k,H),e(o,V),e(o,I),e(I,C),e(o,R),e(o,E),e(E,S),e(o,q),e(o,g),e(g,P),e(a,U),e(a,i),e(i,w),e(w,B),e(i,D),e(i,f),e(f,G),N||(z=[ee(w,"click",M[0]),ee(f,"click",M[1])],N=!0)},p:$,i:$,o:$,d(c){c&&t(p),c&&t(a),N=!1,le(z)}}}function ie(M){return[()=>window.location.href="/blog",()=>window.location.href="/projects"]}class ue extends ae{constructor(p){super();te(this,p,ie,re,oe,{})}}export{ue as default};
